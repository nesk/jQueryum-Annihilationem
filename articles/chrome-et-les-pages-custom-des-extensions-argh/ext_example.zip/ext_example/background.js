chrome.contextMenus.create({
    title: 'Test page custom',

    onclick: function() {
        chrome.tabs.update({
            url: 'custom_page.html'
        });
    }
})